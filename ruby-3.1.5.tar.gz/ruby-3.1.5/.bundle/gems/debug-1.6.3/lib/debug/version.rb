# frozen_string_literal: true

module DEBUGGER__
  VERSION = "1.6.3"
end
