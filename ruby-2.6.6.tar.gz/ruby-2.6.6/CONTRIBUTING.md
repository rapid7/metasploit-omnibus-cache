Please see the [official issue tracker] and wiki [HowToContribute].

[official issue tracker]: https://bugs.ruby-lang.org
[HowToContribute]: https://bugs.ruby-lang.org/projects/ruby/wiki/HowToContribute
