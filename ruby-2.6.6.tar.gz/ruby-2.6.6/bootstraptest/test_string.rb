assert_normal_exit %q{
  inspect.clear
}, '[ruby-core:68110]'
