$:.unshift(File.join(__dir__, '../benchmark-driver/lib'))
require 'benchmark_driver'
