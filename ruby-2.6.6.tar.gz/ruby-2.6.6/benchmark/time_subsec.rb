t = Time.now
4000000.times { t.subsec }
