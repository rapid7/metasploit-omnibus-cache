/* src/include/port/win32_msvc/sys/file.h */
