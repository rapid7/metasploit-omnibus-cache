1000000.times.map{|i| a={}; 8.times{|j| a[j]=j}; a}
