char *ttymsg(struct iovec *iov, size_t iovcnt, char *line, int tmout);

